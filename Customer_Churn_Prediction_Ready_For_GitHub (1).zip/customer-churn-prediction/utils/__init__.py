"""Utility package for the customer churn project."""
