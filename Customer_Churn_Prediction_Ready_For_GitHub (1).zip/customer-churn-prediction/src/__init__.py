"""Source package for training, preprocessing, and prediction."""
